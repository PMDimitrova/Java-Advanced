package bakery.core;

import bakery.common.ExceptionMessages;
import bakery.common.OutputMessages;
import bakery.core.interfaces.Controller;
import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.bakedFoods.interfaces.BaseFood;
import bakery.entities.bakedFoods.interfaces.Bread;
import bakery.entities.bakedFoods.interfaces.Cake;
import bakery.entities.drinks.interfaces.Drink;
import bakery.entities.drinks.interfaces.Tea;
import bakery.entities.drinks.interfaces.Water;
import bakery.entities.tables.interfaces.Table;
import bakery.repositories.interfaces.*;

import static bakery.common.ExceptionMessages.*;
import static bakery.common.OutputMessages.*;

public class ControllerImpl implements Controller {
    private FoodRepository<BakedFood> foodRepository;
    private DrinkRepository<Drink> drinkRepository;
    private TableRepository<Table> tableRepository;

    public ControllerImpl(FoodRepository<BakedFood> foodRepository,
                          DrinkRepository<Drink> drinkRepository,
                          TableRepository<Table> tableRepository) {
        this.foodRepository = foodRepository;
        this.drinkRepository = drinkRepository;
        this.tableRepository = tableRepository;

    }


    @Override
    public String addFood(String type, String name, double price) {
        BakedFood food = foodRepository.getByName(name);

        if (!(food == null)) {
            throw new IllegalArgumentException(String.format(FOOD_OR_DRINK_EXIST, type, name));
        }   //todo check if on upper level we need food type or className
        switch (type) {
            case "Bread":
                food = new Bread(name, 0, price);
                break;
            case "Cake":
                food = new Cake(name, 0, price);
                break;
        }
        foodRepository.add(food);

        return String.format(FOOD_ADDED, name, type);
    } //+

    @Override
    public String addDrink(String type, String name, int portion, String brand) {
        Drink drink = drinkRepository.getByNameAndBrand(name, brand);

        if (!(drink == null)) {
            throw new IllegalArgumentException(String.format(FOOD_OR_DRINK_EXIST, type, name));
        }   //todo check if on upper level we need food type or className
        switch (type) {
            case "Tea":
                drink = new Tea(name, portion, 0, brand);
                break;
            case "Water":
                drink = new Water(name, portion, 0, brand);
                break;
        }
        return String.format(FOOD_ADDED, name, type);
    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {

        return null;
    }

    @Override
    public String reserveTable(int numberOfPeople) {
        //TODO:
        return null;
    }

    @Override
    public String orderFood(int tableNumber, String foodName) {
        //TODO:
        return null;
    }

    @Override
    public String orderDrink(int tableNumber, String drinkName, String drinkBrand) {
        //TODO:
        return null;

    }

    @Override
    public String leaveTable(int tableNumber) {
        //TODO:
        return null;
    }

    @Override
    public String getFreeTablesInfo() {
        //TODO:
        return null;
    }

    @Override
    public String getTotalIncome() {
        //TODO:
        return null;
    }
}
