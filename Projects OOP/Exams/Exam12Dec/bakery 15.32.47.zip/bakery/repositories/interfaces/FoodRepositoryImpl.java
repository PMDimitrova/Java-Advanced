package bakery.repositories.interfaces;

import bakery.entities.bakedFoods.interfaces.BakedFood;

import java.util.Collection;

public class FoodRepositoryImpl implements FoodRepository<BakedFood> {
    private Collection<BakedFood> models;

    @Override
    public BakedFood getByName(String name) {
        return null;
    }

    @Override
    public Collection<BakedFood> getAll() { //must be unmodifiable
        return null;
    }

    @Override
    public void add(BakedFood bakedFood) {

    }
}
