package bakery.repositories.interfaces;

import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.drinks.interfaces.Drink;

import java.util.Collection;

public class DrinkRepositoryImpl implements DrinkRepository<Drink> {

    private Collection<Drink> models;

    @Override
    public Drink getByNameAndBrand(String drinkName, String drinkBrand) {
        return null;
    }

    public Drink getByName(String name){
        return null;
    }
    @Override
    public Collection<Drink> getAll() {//must be unmodifiable
        return null;
    }

    @Override
    public void add(Drink drink) {

    }
}
