package bakery.repositories.interfaces;

import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.tables.interfaces.Table;

import java.util.Collection;

public class TableRepositoryImpl implements TableRepository<Table> {
    private Collection<Table> models;
    @Override
    public Collection<Table> getAll() {//must be unmodifiable
        return null;
    }

    @Override
    public void add(Table table) {

    }

    @Override
    public Table getByNumber(int number) {
        return null;
    }
}
