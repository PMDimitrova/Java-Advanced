import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int count = Integer.parseInt(scan.nextLine());
        String[] tokens = new String[3];

        List<Car> cars = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            tokens = scan.nextLine().split("\\s+");
            Car currentCar = new Car(tokens[0], tokens[1], Integer.parseInt(tokens[2]));
            cars.add(currentCar);
        }
        for (Car car:cars) {
            System.out.println(car.carInfo());
        }
        System.out.println();
    }
}
