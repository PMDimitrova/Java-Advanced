public class Car {
    private String brand;
    private String model;
    private int horsePower;

    public Car(String brand, String model, int horsePower){     //всичко
        this.brand = brand;
        this.model = model;
        this.horsePower = horsePower;
    }

    public Car(String brand, String model){                 //без конете
        this.brand = brand;
        this.model = model;
        this.horsePower = -1;
    }

    public Car (String brand){                              //само марката
        this.brand = brand;
        this.model = "unknown";
        this.horsePower = -1;
    }


    public String carInfo() {
        String info = String.format("The car is: %s %s - %d HP.",
                this.brand, this.model, this.horsePower);
        return info;
    }
}
