import java.lang.invoke.SwitchPoint;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int count = Integer.parseInt(scan.nextLine());
        String[] tokens = new String[3];

        List<Car> cars = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            tokens = scan.nextLine().split("\\s+");
            switch (tokens.length) {
                case 1:
                    Car currentCar = new Car(tokens[0]);
                    cars.add(currentCar);
                    break;
                case 2:
                    Car current = new Car(tokens[0], tokens[1]);
                    cars.add(current);
                    break;
                case 3:
                    Car currentC = new Car(tokens[0], tokens[1], Integer.parseInt(tokens[2]));
                    cars.add(currentC);
                    break;
            }
        }
        for (Car car : cars) {
            System.out.println(car.carInfo());
        }
    }
}
